 <div class="group-progress">
           <h2>Group Progress <br>
               Board</h2>
            <p>Water Challenge</p> 
            
  
           <select class="form-control">
               <option>Sort By</option>
               <option>Name</option>
               <option>Size</option>
            </select>   
            
           <div class="category-list">
              <ul>
                <li>Bob Jacobs <span>10 Days</span></li>
                <li>Steve Smith <span>10 Days</span></li>
                <li>Kelvin Watson<span>10 Days</span></li>
                <li>Graeme Swann<span>10 Days</span></li>
                <li>Chris Daniel<span>10 Days</span></li>
                 <li>Graeme Swann<span>10 Days</span></li>
                <li>Chris Daniel<span>10 Days</span></li>
                 <li>Graeme Swann<span>10 Days</span></li>
                <li>Chris Daniel<span>10 Days</span></li>
              </ul>
           </div> <!--category-list-->
           
           
           <div class="new-badge-maker">
             <h3>NEWEST BADGES</h3>
             
             <select class="form-control">
               <option>Sort By</option>
               <option>Name</option>
               <option>Size</option>
            </select>  
           </div>   <!--new-badge-maker-->
           
           <div class="new-badges-list">
              <ul>
                <li>Merry Parker<img src="<?php bloginfo('template_url'); ?>/images/sign3.png" alt="...." /></li>
                <li>Chris Dawson<img src="<?php bloginfo('template_url'); ?>/images/sign3.png" alt="...." /></li>
                <li>Bob Marley<img src="<?php bloginfo('template_url'); ?>/images/sign3.png" alt="...." /></li>
                <li>Merry Parker<img src="<?php bloginfo('template_url'); ?>/images/sign3.png" alt="...." /></li>
                <li>Chris Dawson<img src="<?php bloginfo('template_url'); ?>/images/sign3.png" alt="...." /></li>
                <li>Bob Marley<img src="<?php bloginfo('template_url'); ?>/images/sign3.png" alt="...." /></li>
                <li>Merry Parker<img src="<?php bloginfo('template_url'); ?>/images/sign3.png" alt="...." /></li>
                <li>Chris Dawson<img src="<?php bloginfo('template_url'); ?>/images/sign3.png" alt="...." /></li>
                <li>Bob Marley<img src="<?php bloginfo('template_url'); ?>/images/sign3.png" alt="...." /></li>
              </ul>
           </div> 
           
           <div class="invitation-form">
             <h3>Invite Friends</h3>
             
             <input type="text" class="form-control" placeholder="Enter Email">
             
             <input type="text" class="form-control" placeholder="Enter Email">
             <input type="text" class="form-control" placeholder="Enter Email">
             
             <input type="button" class="btn btn-default btn-profil" value="Send Invite">
             
           </div> <!--invitation-form Close-->
         </div> 