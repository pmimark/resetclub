<?php
echo date('Y-m-d', strtotime('2016-06-16'. ' + 1 days')); 
?>