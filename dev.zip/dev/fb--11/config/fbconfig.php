<?php
define('APP_ID', '1706820956201572');
define('APP_SECRET', 'bc958bb454e292b56e73903ff847e278');
?>
