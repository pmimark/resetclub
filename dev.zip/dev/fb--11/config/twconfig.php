<?php

define('YOUR_CONSUMER_KEY', 'qP7hZfZenTA0Qb7MCYc6g');
define('YOUR_CONSUMER_SECRET', 'fP4udbuDCYBuGzmuL6BstqFqp0LPzTcOcdObeGF0ew');



?>
